SUMBAJANG V19 — PORT POLYTRON OSAKI

Ini adalah pembaruan source widget Home SUMBAJANG V19 untuk CleanYourTV Polytron.
Menggunakan SumbajangWidgetView dan Controller dari source CleanYourTV V20.2 yang sudah membawa V19,
termasuk logo PNG terkunci dan background masjid. Script mempertahankan MainActivity fork Polytron,
lalu memasang kontrol Dock-Focus Auto Hide.

Upload ZIP ini ke root repository dengan nama SUMBAJANG-Polytron-GitHub-Patch.zip,
menimpa ZIP patch lama. Workflow yang sudah ada akan otomatis mengekstrak dan menjalankan
apply_sumbajang.py sebelum Gradle build.
