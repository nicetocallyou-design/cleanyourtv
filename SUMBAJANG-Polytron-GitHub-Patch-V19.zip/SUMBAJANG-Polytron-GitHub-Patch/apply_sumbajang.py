#!/usr/bin/env python3
"""Port the user's V19 SUMBAJANG Home widget source into the Polytron CleanYourTV fork.

This deliberately preserves the fork's MainActivity and applies only the V19 widget/focus hooks.
All logo assets are SHA-256 checked before any project file is written.
"""
from pathlib import Path
import argparse, hashlib, re, shutil, sys

MASTER_SHA = '031882616a7a9f000e87fb005e2cc9554026fbbe5009263a45db63b8626e32ff'
RUNTIME_SHA = '9bbe1978a9aad1dbf088b22128914404e893448dc977739eec89dc9517819b87'


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected exactly one anchor, found {count}')
    return text.replace(old, new, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--launcher', default='launcher')
    args = ap.parse_args()
    root = Path(args.launcher).resolve()
    src = Path(__file__).resolve().parent / 'files'
    java_dir = root / 'app/src/main/java/com/gathin/tvhome'
    main_java = java_dir / 'MainActivity.java'
    manifest = root / 'app/src/main/AndroidManifest.xml'
    view_src = src / 'SumbajangWidgetView.java'
    controller_src = src / 'SumbajangWidgetController.java'
    logo_src = src / 'sumbajang_logo.png'
    master_src = src / 'sumbajang_logo_master.png'
    mosque_src = src / 'sumbajang_mosque.webp'

    required = [main_java, manifest, view_src, controller_src, logo_src, master_src, mosque_src]
    for p in required:
        if not p.is_file():
            raise RuntimeError(f'Required file missing: {p}')
    if sha(master_src) != MASTER_SHA:
        raise RuntimeError('Master logo SHA-256 mismatch; refusing to alter project.')
    if sha(logo_src) != RUNTIME_SHA:
        raise RuntimeError('Runtime logo SHA-256 mismatch; refusing to alter project.')

    activity = main_java.read_text(encoding='utf-8')
    manifest_text = manifest.read_text(encoding='utf-8')

    # V19 dock-focus state.
    field_anchor = '    private boolean weatherWidgetHiddenForGridNavigation;'
    if 'SUMBAJANG_WIDGET_DOCK_VISIBILITY_V19' not in activity:
        activity = replace_once(
            activity, field_anchor,
            field_anchor + '\n    // SUMBAJANG_WIDGET_DOCK_VISIBILITY_V19: hide below the dock, restore on dock focus.\n'
            '    private boolean sumbajangWidgetHiddenForGridNavigation;',
            'V19 state field')

        method_anchor = 'private void hideWeatherWidgetForGridNavigation() {'
        methods = '''// SUMBAJANG_WIDGET_DOCK_VISIBILITY_V19:
    // Only the actual dock row restores the prayer widget; header/settings focus does not.
    private boolean isViewInsideDockRow(View candidate) {
        if (candidate == null || grid == null) return false;
        View current = candidate;
        while (current != null && current != grid) {
            android.view.ViewParent parent = current.getParent();
            if (parent == grid) {
                int position = grid.getChildAdapterPosition(current);
                if (position == RecyclerView.NO_POSITION) return false;
                if (singleRow) return true;
                return dockRow && position < COLUMNS;
            }
            current = parent instanceof View ? (View) parent : null;
        }
        return false;
    }

    private void hideSumbajangWidgetForGridNavigation() {
        if (sumbajangWidgetHiddenForGridNavigation) return;
        sumbajangWidgetHiddenForGridNavigation = true;
        SumbajangWidgetController.setWidgetVisible(root, false);
    }

    private void showSumbajangWidgetWhenDockFocused(View newFocus) {
        if (!sumbajangWidgetHiddenForGridNavigation || !isViewInsideDockRow(newFocus)) return;
        sumbajangWidgetHiddenForGridNavigation = false;
        SumbajangWidgetController.setWidgetVisible(root, true);
    }

    '''
        activity = replace_once(activity, method_anchor, methods + method_anchor, 'V19 focus methods')

        # Existing global focus listener: hide when focus enters app rows; reveal only on dock focus.
        old_listener = '''        // WEATHER_WIDGET_EXCLUDE_DOCK_V3_FOCUS
        getWindow().getDecorView().getViewTreeObserver().addOnGlobalFocusChangeListener((oldF, newF) -> {
            boolean inScrollableAppRows = isViewInsideAppGrid(newF);
            if (inScrollableAppRows) {
                if (weatherWidgetHiddenForGridNavigation && weatherWidget != null) {
                    weatherWidget.setVisibility(View.GONE);
                }
            } else {
                // This includes the dock row: make sure the weather widget is visible there.
                hideGlass();
                showWeatherWidgetAfterGridFocusLeaves(newF);
            }
        });'''
        new_listener = '''        // WEATHER_WIDGET_EXCLUDE_DOCK_V3_FOCUS
        getWindow().getDecorView().getViewTreeObserver().addOnGlobalFocusChangeListener((oldF, newF) -> {
            boolean inScrollableAppRows = isViewInsideAppGrid(newF);
            if (inScrollableAppRows) {
                if (weatherWidgetHiddenForGridNavigation && weatherWidget != null) {
                    weatherWidget.setVisibility(View.GONE);
                }
                hideSumbajangWidgetForGridNavigation();
            } else {
                // SUMBAJANG is restored only when focus returns to the actual dock row.
                showSumbajangWidgetWhenDockFocused(newF);
                hideGlass();
                showWeatherWidgetAfterGridFocusLeaves(newF);
            }
        });'''
        activity = replace_once(activity, old_listener, new_listener, 'V19 global focus listener')

        # Predictive remote navigation: hide before entering rows below dock.
        old_dispatch = '''            if (hideForDestination) {
                hideWeatherWidgetForGridNavigation();
            } else {
                // Dock/top-bar navigation is not a reason to hide the weather widget.
                showWeatherWidgetAfterGridFocusLeaves(keyFocus);
            }'''
        new_dispatch = '''            if (hideForDestination) {
                hideWeatherWidgetForGridNavigation();
                hideSumbajangWidgetForGridNavigation();
            } else {
                // Restore SUMBAJANG only when the predicted destination is in the dock.
                if (predictedFocus != null && isViewInsideDockRow(predictedFocus)) {
                    showSumbajangWidgetWhenDockFocused(predictedFocus);
                }
                showWeatherWidgetAfterGridFocusLeaves(keyFocus);
            }'''
        activity = replace_once(activity, old_dispatch, new_dispatch, 'V19 remote dispatch')

    # Ensure controller install is present exactly once.
    install_call = '        SumbajangWidgetController.install(this, root);'
    if install_call not in activity:
        anchor = '        wallpaperPlayer = new WallpaperPlayer(this, root, cfg);'
        activity = replace_once(activity, anchor, anchor + '\n' + install_call, 'controller install')
    elif activity.count(install_call) != 1:
        raise RuntimeError('Sumbajang controller install call is duplicated.')

    # Check layout IDs consumed by the V19 controller.
    layout = root / 'app/src/main/res/layout/activity_main.xml'
    if not layout.is_file():
        raise RuntimeError('activity_main.xml not found')
    layout_text = layout.read_text(encoding='utf-8')
    for ident in ['root', 'leftBlock', 'heroName', 'hero', 'date']:
        if f'@+id/{ident}' not in layout_text and f'@id/{ident}' not in layout_text:
            raise RuntimeError(f'Layout ID required by SUMBAJANG not found: {ident}')

    # Add manifest permissions if missing.
    if 'android.permission.INTERNET' not in manifest_text:
        manifest_text = manifest_text.replace('<application',
            '    <uses-permission android:name="android.permission.INTERNET" />\n    <application', 1)
    if 'android.permission.ACCESS_COARSE_LOCATION' not in manifest_text:
        manifest_text = manifest_text.replace('<application',
            '    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />\n    <application', 1)

    # Merge the custom ID safely.
    ids_file = root / 'app/src/main/res/values/ids.xml'
    ids_file.parent.mkdir(parents=True, exist_ok=True)
    if ids_file.exists():
        ids_text = ids_file.read_text(encoding='utf-8')
        if 'sumbajang_widget_tag' not in ids_text:
            ids_text = ids_text.replace('</resources>', '    <item name="sumbajang_widget_tag" type="id" />\n</resources>')
    else:
        ids_text = '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <item name="sumbajang_widget_tag" type="id" />\n</resources>\n'

    # Write only after all validation has succeeded.
    backup = root / '.sumbajang-v19-backup'
    backup.mkdir(exist_ok=True)
    for p in [main_java, manifest, ids_file]:
        if p.exists():
            shutil.copy2(p, backup / (p.name + '.before-v19'))
    (java_dir / 'SumbajangWidgetView.java').write_bytes(view_src.read_bytes())
    (java_dir / 'SumbajangWidgetController.java').write_bytes(controller_src.read_bytes())
    (root / 'app/src/main/assets').mkdir(parents=True, exist_ok=True)
    shutil.copy2(logo_src, root / 'app/src/main/assets/sumbajang_logo.png')
    shutil.copy2(master_src, root / 'app/src/main/assets/sumbajang_logo_master.png')
    shutil.copy2(src / 'SUMBAJANG_LOGO_LOCK.txt', root / 'app/src/main/assets/SUMBAJANG_LOGO_LOCK.txt')
    (root / 'app/src/main/res/drawable-nodpi').mkdir(parents=True, exist_ok=True)
    shutil.copy2(mosque_src, root / 'app/src/main/res/drawable-nodpi/sumbajang_mosque.webp')
    main_java.write_text(activity, encoding='utf-8')
    manifest.write_text(manifest_text, encoding='utf-8')
    ids_file.write_text(ids_text, encoding='utf-8')

    # Verify copied image assets remain byte-identical.
    assert sha(root / 'app/src/main/assets/sumbajang_logo.png') == RUNTIME_SHA
    assert sha(root / 'app/src/main/assets/sumbajang_logo_master.png') == MASTER_SHA
    print('SUMBAJANG V19 Polytron port integrated successfully.')
    print('Copied V19 View + Controller + locked original logos + mosque background.')
    print('Added dock-focus auto-hide/restore to the existing Polytron CleanYourTV MainActivity.')
    print('Original launcher MainActivity backed up in .sumbajang-v19-backup.')

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'ERROR: {e}', file=sys.stderr)
        sys.exit(1)
