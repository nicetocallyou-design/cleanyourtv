# SUMBAJANG — Integrasi CleanYourTV Polytron OSAKI

Paket ini menyisipkan widget Sumbajang native ke dalam launcher CleanYourTV yang sedang dibangun oleh GitHub Actions. Sumbajang bukan APK terpisah.

## Apa yang dilakukan
- Menambahkan kartu jadwal Subuh, Zuhur, Ashar, Magrib, Isya, dan countdown ke salat berikutnya.
- Meminta izin lokasi Android; jika layanan lokasi STB tidak tersedia, widget mencoba perkiraan lokasi jaringan/IP.
- Mengambil jadwal dari dataset Sajadah yang menyalurkan jadwal Kemenag RI.
- Menyediakan pemilih provinsi dan kabupaten/kota di TV dengan remote.
- Mencoba memuat foto masjid kota dan menyimpan cache lokal.

## Instalasi lewat GitHub Actions dari HP
1. Upload file `SUMBAJANG-Polytron-GitHub-Patch.zip` ke **root** repository `nicetocallyou-design/cleanyourtv` (sejajar dengan folder `launcher`). Jangan ekstrak file ZIP sebelum upload.
2. Buka `.github/workflows/polytron-osaki-build.yml` di GitHub, tekan Edit (ikon pensil).
3. Buka file `WORKFLOW-STEP.txt` dalam paket ini, salin blok YAML di situ, lalu sisipkan setelah langkah `Setup Gradle` dan sebelum `Build APK`.
4. Commit perubahan workflow.
5. Jalankan workflow **Build CleanYourTV APK for Polytron OSAKI**.
6. Unduh artifact `CleanYourTV-Polytron-OSAKI-APK` dari run terbaru dan pasang APK hasilnya.

## Setelah widget tampil
- Pilih lokasi kabupaten/kota yang benar jika lokasi otomatis tidak akurat.
- Tekan OK pada kartu untuk memuat ulang jadwal/foto atau memilih lokasi.
- Tekan lama pada kartu untuk melihat sumber jadwal dan atribusi foto.

## Kompatibilitas
Source disiapkan untuk layout repo saat ini yang memiliki view `root`, `leftBlock`, `heroName`, dan `hero`. Script memeriksa anchor dan ID sebelum menulis. Jika source launcher berubah, proses build berhenti dengan pesan validasi alih-alih memaksakan patch.
