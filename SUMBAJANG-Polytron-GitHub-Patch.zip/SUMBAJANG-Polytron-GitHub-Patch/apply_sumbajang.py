#!/usr/bin/env python3
"""Integrate the existing SUMBAJANG native widget into the checked-out CleanYourTV launcher."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

ANDROID_NS = "http://schemas.android.com/apk/res/android"


def fail(message: str) -> None:
    raise SystemExit(f"SUMBAJANG integration stopped: {message}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--launcher", default="launcher", help="Path to CleanYourTV launcher project")
    args = parser.parse_args()

    package = Path(__file__).resolve().parent
    launcher = Path(args.launcher).resolve()
    main_java = launcher / "app/src/main/java/com/gathin/tvhome/MainActivity.java"
    manifest = launcher / "app/src/main/AndroidManifest.xml"
    layout = launcher / "app/src/main/res/layout/activity_main.xml"
    java_dir = launcher / "app/src/main/java/com/gathin/tvhome"
    values_dir = launcher / "app/src/main/res/values"
    ids_file = values_dir / "ids.xml"

    for path in (main_java, manifest, layout):
        if not path.is_file():
            fail(f"required file not found: {path}")

    controller_src = package / "src/com/gathin/tvhome/SumbajangWidgetController.java"
    view_src = package / "src/com/gathin/tvhome/SumbajangWidgetView.java"
    ids_src = package / "res/values/ids.xml"
    for path in (controller_src, view_src, ids_src):
        if not path.is_file():
            fail(f"patch source missing: {path}")

    main_text = main_java.read_text(encoding="utf-8")
    anchor = "wallpaperPlayer = new WallpaperPlayer(this, root, cfg);"
    call = "SumbajangWidgetController.install(this, root);"
    if call not in main_text:
        if main_text.count(anchor) != 1:
            fail("CleanYourTV integration anchor was not found exactly once; no source files changed")
        main_text = main_text.replace(anchor, anchor + "\n        " + call, 1)

    layout_text = layout.read_text(encoding="utf-8")
    for view_id in ("root", "leftBlock", "heroName", "hero"):
        if f'@+id/{view_id}' not in layout_text and f'@id/{view_id}' not in layout_text:
            fail(f"layout id {view_id} is missing; launcher layout may have changed")

    manifest_text = manifest.read_text(encoding="utf-8")
    permissions = (
        "android.permission.INTERNET",
        "android.permission.ACCESS_COARSE_LOCATION",
    )
    additions = []
    for permission in permissions:
        needle = f'android:name="{permission}"'
        if needle not in manifest_text:
            additions.append(f'    <uses-permission android:name="{permission}" />')
    if additions:
        import re
        match = re.search(r"(?m)^(\s*)<application\b", manifest_text)
        if match is None or len(re.findall(r"(?m)^\s*<application\b", manifest_text)) != 1:
            fail("could not safely locate AndroidManifest application element")
        indent = match.group(1)
        additions_text = "\n".join(indent + line.strip() for line in additions)
        manifest_text = manifest_text[:match.start()] + additions_text + "\n\n" + manifest_text[match.start():]

    # Merge the generated resource ID without disturbing any existing values/ids.xml entries.
    if ids_file.exists():
        ids_text = ids_file.read_text(encoding="utf-8")
        if 'name="sumbajang_widget_tag"' not in ids_text:
            if "</resources>" not in ids_text:
                fail("existing res/values/ids.xml has no closing resources tag")
            ids_text = ids_text.replace("</resources>", '    <item name="sumbajang_widget_tag" type="id" />\n</resources>', 1)
    else:
        ids_text = ids_src.read_text(encoding="utf-8")

    # Write changes only after every preflight validation succeeds.
    java_dir.mkdir(parents=True, exist_ok=True)
    values_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(controller_src, java_dir / controller_src.name)
    shutil.copy2(view_src, java_dir / view_src.name)
    main_java.write_text(main_text, encoding="utf-8", newline="")
    manifest.write_text(manifest_text, encoding="utf-8", newline="")
    ids_file.write_text(ids_text, encoding="utf-8", newline="")

    print("SUMBAJANG integrated successfully.")
    print("Added native prayer card, runtime location flow, Sajadah timetable source, and city selector.")
    print("Files updated: MainActivity.java, AndroidManifest.xml, values/ids.xml; two Java classes copied.")


if __name__ == "__main__":
    main()
